public class MainClass {
	public static void main(String argd[]){
		System.out.println("你好，请编译我。");
		A a = new A();
		a.fA();
		B b = new B();
		b.fB();
	}	

}