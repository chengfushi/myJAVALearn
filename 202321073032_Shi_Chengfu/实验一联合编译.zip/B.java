public class B{
	void fB() {
		System.out.println("I am B");
	}
}