public class A{
	void fA() {
		System.out.println("I am A");
	}
}