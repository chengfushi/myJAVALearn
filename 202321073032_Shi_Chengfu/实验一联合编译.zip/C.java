public class C{
	void fC() {
		System.out.println("I am C");
	}
}